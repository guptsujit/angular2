export class Contactus { 
    constructor ( 
     public firstname : string,
     public lastname : string,
     public email : string,
     public phone : number,
     public address : string,
     public city : string,
     public state : string,
     public zip : number,
     public website : string,
     public hosting : string,
     public comment : string

    ) {  } 
 }