import { Component, OnInit } from '@angular/core';
import { Contactus } from './contactus';
import { NgForm } from '@angular/forms';

@Component({
  templateUrl: './contactus-form.component.html',
  styles :  ['.help-block { color: red; }']

})
export class ContactusFormComponent implements OnInit{
  model:Contactus;
  constructor(){
   
  //  formData.firstname = "tester";
  }
  ngOnInit() {
    this.model = {
      firstname:'',lastname:'',email:'',phone:123,address:'',city:'',state:'',zip:123,website:'',
      hosting:'',comment:''
    
    };
  }
  get diagnostic() {
     return JSON.stringify(this.model); 
    }
  contact(formData):void{
    console.log('Reactive Form Data: ')
    console.log(formData);
  }
}
