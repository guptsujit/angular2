import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './aboutus.component.html',

})
export class AboutusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
