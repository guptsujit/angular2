import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-menu',
  templateUrl: './home-menu.component.html',

})
export class HomeMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
